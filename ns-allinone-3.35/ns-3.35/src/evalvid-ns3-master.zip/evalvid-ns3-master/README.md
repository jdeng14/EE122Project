NS3 Evalvid module by GERCOM - www.gercom.ufpa.br

Author: Billy Pinheiro <haquiticos@gmail.com>

1 - Unpack the evalvid.zip file inside the folder  ns-3.16/src/

2 - Make sure that the folder "evalvid" has been correctly unpacked

3 - Move the highway_cif.mp4 and st_highway_cif.st files to ns-3.16/ 

4 - ./waf configure --enable-examples

5 - Run  ./waf build

6 - Run ./waf --run "evalvid-client-server" or ./waf --run "evalvid-lte"

Have fun!!!